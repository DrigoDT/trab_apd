from GUI import interface_usuario

def principal():
    interface_usuario.mostrar_menu()

if __name__ == "__main__":
    principal()
