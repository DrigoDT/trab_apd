from logica import filmes
from gui import menu_usuario



def dados_filmes(filme):
    codigo = filme[0]
    t = filme[1]
    a = filme[2]
    
    
    print ("Codigo do Filme: ", codigo)
    print ("Ano do Filme: ",  a)
    print ("Título do Filme ", t)

        
    print()
    
        

def menu_buscar():
    print ("\nBuscar Filme \n")
    codigo = int(input("Código: "))
    f = filmes.buscar_filmes(codigo_filmes)
    if (f == None):
        print ("Filme não encontrado")
    else:
        dados_filme(f)
    
        
def menu_adicionar():
    print ("\nAdicionar Filme  \n")
    codigo_filme = int(input("Codigo do Filme: "))
    t = int (input("Título do Filme: "))
    a = str(input("Ano do filme: "))
    adicionar = filmes.adicionar_filme(codigo_filme,t,a)
    print ("Filme Adicionado")
    
    
def menu_listar():
    print ("\nListar Filmes \n")
    filmes = filmes.listar_filmes()
    for f in filmes:
        dados_filme(f)




def menu_remover():
    print ("\nRemover Filme \n")
    codigo = int(input("Codigo Filme: "))
    f = filmes.remover_filmes(codigo_filmes)
    if (f == False):
        print ("Filme não encontrado")
    else:
        print ("Filme removido")
    

def mostrar_menu():
    run_filmes = True
    menu = ("\n----------------\n"+
             "(1) Adicionar Filme \n" +
             "(2) Listar Filmes \n" +
             "(3) Buscar Filme por Código \n" +
             "(4) Remover Filme \n" +
             "(0) Voltar\n"+
            "----------------")
    
    while(run_filmes):
        print (menu)
        op = int(input("Digite sua escolha: "))

        if (op == 1):
            menu_adicionar()
        elif(op == 2):
            menu_listar()
        elif(op == 3):       
            menu_buscar()
        elif (op == 4):
            menu_remover()
        elif (op == 0):
            run_consulta = False
            
