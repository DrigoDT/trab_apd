from logica import usuario

filmes = []
codigo_filme = 0

def _codigo_filme():
    global codigo_filme
    codigo_filme += 1
    return codigo_filme
    
    

def adicionar_filme(titulo,ano):
    codigo = _codigo_filme()
    
    t = usuario.buscar_usuario()
    a = usuario.buscar_usuario(titulo,ano)
   
    filme = [codigo,t, a,]
    filmes.append(filme)
    
def listar_filmes():
    return filmes   

def buscar_filmes(codigo_filmes):
    for f in filmes:
        if (f[0] == codigo_filmes):
            return f
    return None

def remover_filmes(codigo_filmes):
    for f in filmes:
        if (f[0] == codigo_filmes):
            filmes.remove(f)
            return True
    return False


    
def iniciar_filmes():
    marcar_consulta("Homem de Ferro 3", 2013)
    marcar_consulta("Os Vingadores", 2012)
   
