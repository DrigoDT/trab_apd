from logica import usuario
from logica import filmes

usuario.adicionar_usuario()
filmes.buscar_filmes()




