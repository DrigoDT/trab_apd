usuario = []


def adicionar_usuario(nome, email, senha, idade, cpf):    
    usuario = [nome, email, senha, idade, cpf]
    usuario.append(usuario)
    
def listar_usuario():
    return usuario

def buscar_usuario(cpf):
    for u in usuario:
        if (u[0] == cpf):
            return u
    return None
        
def remover_usuario(cpf):
    for u in usuario:
        if (u[0] == cpf):
            usuario.remove(u)
            return True
    return False

