filme=[]

def adicionar_filme(titulo,genero,ano):
    filme=[titulo,genero,ano]
    filme.append(filme)

def lista_filme():
    return filme

def buscar_filme():
    
 

def remover_filme():

def iniciar_filme():
